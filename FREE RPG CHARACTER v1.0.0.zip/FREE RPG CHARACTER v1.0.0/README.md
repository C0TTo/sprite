2D Character Animation Asset Pack

A 2D pixel art character animation pack designed for platformer games and other 2D projects.
V1.0.0

Specifications

- Character Size: 32 × 32 px
- Canvas Size: 160 × 160 px
- Included Formats: Spritesheets and separate images
- Animation Type: 2D frame-by-frame animation

Animations

Main Animations

1. Idle — 8 frames
2. Walk — 10 frames
3. Run — 10 frames
4. Jump — 4 frames
5. Fall — 5 frames
6. Slide — 5 frames
7. Wall Hold — 4 frames
8. Ledge Hold — 4 frames
9. Attack 1 — 8 frames
10. Attack 2 — 8 frames
11. Wide Attack — 10 frames
12. Up Attack — 5 frames
13. Jump Up Attack — 6 frames
14. Fall Down Attack — 7 frames
15. Knockback — 5 frames
16. Death — 9 frames

Transitions

1. Run Start — 1 frame
2. Run Stop — 6 frames
3. Slide Start — 4 frames
4. Slide End — 5 frames
5. Jump Apex — 5 frames
6. Land — 4 frames
7. Land from Distance — 8 frames
8. Wall Hold Start — 3 frames
9. Ledge Hold / Climb Up — 5 frames
10. Knockback Recover — 7 frames

License

This asset pack can be used for both commercial and non-commercial projects.

You MAY:

- Use the assets in commercial games and projects.
- Use the assets in non-commercial projects.
- Modify the assets for use within your projects.
- Use the assets in personal, indie, and professional projects.

You MAY NOT:

- Resell, redistribute, or re-upload the original assets.
- Sell or redistribute modified versions of the assets as standalone assets.
- Include the assets in another asset pack intended for redistribution or sale.
- Claim the original assets as your own work.

The assets are licensed for use within your projects and are not sold with ownership or redistribution rights.

Follow ibrahimart on itch.io for more free and paid asset packs:
https://ibrahimart.itch.io